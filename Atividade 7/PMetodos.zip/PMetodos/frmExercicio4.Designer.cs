﻿namespace PMetodos
{
    partial class frmExercicio4
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnqtdadecaracnumericos = new System.Windows.Forms.Button();
            this.btnPrimeiroCarac = new System.Windows.Forms.Button();
            this.btnqtdadecaracalfabeticos = new System.Windows.Forms.Button();
            this.richTextFrase = new System.Windows.Forms.RichTextBox();
            this.lbl1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnqtdadecaracnumericos
            // 
            this.btnqtdadecaracnumericos.Location = new System.Drawing.Point(94, 332);
            this.btnqtdadecaracnumericos.Name = "btnqtdadecaracnumericos";
            this.btnqtdadecaracnumericos.Size = new System.Drawing.Size(186, 91);
            this.btnqtdadecaracnumericos.TabIndex = 0;
            this.btnqtdadecaracnumericos.Text = "Qtdade Caracteres Numericos";
            this.btnqtdadecaracnumericos.UseVisualStyleBackColor = true;
            this.btnqtdadecaracnumericos.Click += new System.EventHandler(this.Btnqtdadecaracnumericos_Click);
            // 
            // btnPrimeiroCarac
            // 
            this.btnPrimeiroCarac.Location = new System.Drawing.Point(311, 332);
            this.btnPrimeiroCarac.Name = "btnPrimeiroCarac";
            this.btnPrimeiroCarac.Size = new System.Drawing.Size(169, 91);
            this.btnPrimeiroCarac.TabIndex = 1;
            this.btnPrimeiroCarac.Text = "Primeiro caracter branco";
            this.btnPrimeiroCarac.UseVisualStyleBackColor = true;
            this.btnPrimeiroCarac.Click += new System.EventHandler(this.BtnPrimeiroCarac_Click);
            // 
            // btnqtdadecaracalfabeticos
            // 
            this.btnqtdadecaracalfabeticos.Location = new System.Drawing.Point(521, 332);
            this.btnqtdadecaracalfabeticos.Name = "btnqtdadecaracalfabeticos";
            this.btnqtdadecaracalfabeticos.Size = new System.Drawing.Size(189, 91);
            this.btnqtdadecaracalfabeticos.TabIndex = 2;
            this.btnqtdadecaracalfabeticos.Text = "Quantidade de caracteres alfabeticos";
            this.btnqtdadecaracalfabeticos.UseVisualStyleBackColor = true;
            this.btnqtdadecaracalfabeticos.Click += new System.EventHandler(this.Btnqtdadecaracalfabeticos_Click);
            // 
            // richTextFrase
            // 
            this.richTextFrase.Location = new System.Drawing.Point(37, 54);
            this.richTextFrase.Name = "richTextFrase";
            this.richTextFrase.Size = new System.Drawing.Size(731, 248);
            this.richTextFrase.TabIndex = 3;
            this.richTextFrase.Text = "";
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Location = new System.Drawing.Point(34, 20);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(33, 13);
            this.lbl1.TabIndex = 4;
            this.lbl1.Text = "Frase";
            // 
            // frmExercicio4
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.lbl1);
            this.Controls.Add(this.richTextFrase);
            this.Controls.Add(this.btnqtdadecaracalfabeticos);
            this.Controls.Add(this.btnPrimeiroCarac);
            this.Controls.Add(this.btnqtdadecaracnumericos);
            this.Name = "frmExercicio4";
            this.Text = "frmExercicio4";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnqtdadecaracnumericos;
        private System.Windows.Forms.Button btnPrimeiroCarac;
        private System.Windows.Forms.Button btnqtdadecaracalfabeticos;
        private System.Windows.Forms.RichTextBox richTextFrase;
        private System.Windows.Forms.Label lbl1;
    }
}