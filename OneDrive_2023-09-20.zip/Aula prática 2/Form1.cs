﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Aula_prática_2
{
    public partial class Form1 : Form
    {
        double numero1, numero2, resultado;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TextBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            txt1.Clear();
            txt2.Clear();
            txt3.Clear();
            txt1.Focus();
        }

        private void Txt1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Txt2_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt2.Text, out numero2))
            {
                MessageBox.Show("Numero Inválido");
                txt2.Focus();
            }
        }

        private void Btn1_Click(object sender, EventArgs e)
        {
            resultado = numero1 + numero2;
            txt3.Text = resultado.ToString();
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            resultado = numero1 - numero2;
            txt3.Text = resultado.ToString();
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            resultado = numero1 * numero2;
            txt3.Text = resultado.ToString();
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            if (numero2==0)
            {
                MessageBox.Show("não pode dividir por zero!");
                txt2.Focus();
            }
            else
            {
                resultado = numero1 / numero2;
                txt3.Text = resultado.ToString();
            }
        }

        private void Btn6_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Você deseja sair mesmo?", "Saída",MessageBoxButtons.YesNo,MessageBoxIcon.Question)==DialogResult.Yes)
            {
                Close();
            }
        }

        private void Txt1_Validated(object sender, EventArgs e)
        {
            if (!Double.TryParse(txt1.Text,out numero1))
            {
                MessageBox.Show("Numero Inválido");
                txt1.Focus();
            }
        }

        private void Txt1_TabIndexChanged(object sender, EventArgs e)
        {

        }
    }
}
